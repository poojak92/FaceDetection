package id.singd.android.signdsdk.commands

interface ICommand {
    suspend fun execute(executor: Any)
}