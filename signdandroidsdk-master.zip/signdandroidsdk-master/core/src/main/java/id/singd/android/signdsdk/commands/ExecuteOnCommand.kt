package id.singd.android.signdsdk.commands

abstract class ExecuteOnCommand(private val action: (Any) -> Unit) : ICommand {

    override suspend fun execute(executor: Any) {
        action(executor)
    }
}