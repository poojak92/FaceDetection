package id.singd.android.signdsdk.commands


class ExecuteOnActivityCommand(action: (Any) -> Unit) : ExecuteOnCommand(action) {
}