package id.singd.android.signdsdk

enum class HttpMethods {
    GET,
    POST,
    DELETE,
    PUT
}