package id.singd.android.mitek

class SelectorItems(internal val item: String, internal val display: String) {

    override fun toString(): String {
        return display
    }
}