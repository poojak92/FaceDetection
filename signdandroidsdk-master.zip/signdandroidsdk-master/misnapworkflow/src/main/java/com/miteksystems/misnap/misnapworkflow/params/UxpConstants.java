package com.miteksystems.misnap.misnapworkflow.params;

/**
 * Created by jlynch on 11/14/17.
 */

public class UxpConstants {
    public static final String MISNAP_UXP_TOUCH_SCREEN = "TS";
    public static final String MISNAP_UXP_GHOST_IMAGE_BEGINS = "IB";
    public static final String MISNAP_UXP_GHOST_IMAGE_ENDS = "IE";
    public static final String MISNAP_UXP_HELP_END = "TE";
}
